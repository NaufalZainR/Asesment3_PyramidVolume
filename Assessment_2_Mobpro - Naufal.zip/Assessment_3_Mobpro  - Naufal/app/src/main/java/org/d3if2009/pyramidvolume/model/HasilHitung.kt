package org.d3if2009.pyramidvolume.model

data class HasilHitung(
    val panjang: Float,
    val lebar: Float,
    val tinggi: Float,
    val hasil: Float
)