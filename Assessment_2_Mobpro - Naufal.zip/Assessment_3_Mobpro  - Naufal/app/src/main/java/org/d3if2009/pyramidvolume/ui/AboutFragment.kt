package org.d3if2009.pyramidvolume.ui

import androidx.fragment.app.Fragment
import org.d3if2009.pyramidvolume.R

class AboutFragment: Fragment(R.layout.fragment_about) {
}